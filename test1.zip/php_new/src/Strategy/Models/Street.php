<?php


namespace Datamints\HashCode\Qualifier2021\Strategy\Models;


class Street {
	public $name = '';
	public $duration = 0;
	public $intersectionStart = 0;
	public $intersectionEnd = 0;
}