<?php


namespace Datamints\HashCode\Qualifier2021\Strategy\Models;


class Intersection {

}